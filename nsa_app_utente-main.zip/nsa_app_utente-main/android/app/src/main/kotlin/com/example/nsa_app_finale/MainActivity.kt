package com.example.nsa_app_finale

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
