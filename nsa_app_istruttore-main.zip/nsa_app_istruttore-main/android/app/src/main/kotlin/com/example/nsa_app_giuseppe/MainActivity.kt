package com.example.nsa_app_giuseppe

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
